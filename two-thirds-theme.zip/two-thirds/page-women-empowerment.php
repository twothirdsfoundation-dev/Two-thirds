<?php
/**
 * Template Name: Women's Empowerment Page
 */
?>
<?php
/**
 * Main template file for Two-Thirds Community Foundation theme
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class('min-h-screen bg-[#FAF9F6] text-[#1A2D37] font-sans antialiased'); ?>>
    <?php wp_body_open(); ?>
    
    <script>
    window.wpPosts = [
        <?php
        $args = array('post_type' => 'post', 'posts_per_page' => -1, 'post_status' => 'publish');
        $query = new WP_Query($args);
        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
                $post_data = array(
                    'id' => strval(get_the_ID()),
                    'slug' => basename(get_permalink()),
                    'title' => get_the_title(),
                    'excerpt' => get_the_excerpt(),
                    'content' => array(wp_strip_all_tags(get_the_content())),
                    'date' => get_the_date('M j, Y'),
                    'author' => get_the_author(),
                    'readTime' => '5 min read',
                    'image' => get_the_post_thumbnail_url(get_the_ID(), 'full') ?: '',
                    'category' => 'Field Diaries'
                );
                echo json_encode($post_data) . ',';
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
    ];

    window.wpImpactStories = [
        <?php
        $args = array('post_type' => 'impact_story', 'posts_per_page' => -1, 'post_status' => 'publish');
        $query = new WP_Query($args);
        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
                $quote = get_post_meta(get_the_ID(), 'impact_quote', true) ?: get_the_excerpt();
                $author_role = get_post_meta(get_the_ID(), 'author_role', true) ?: 'Community Member';
                $avatar_initials = get_post_meta(get_the_ID(), 'avatar_initials', true) ?: substr(get_the_title(), 0, 2);
                
                $story_data = array(
                    'id' => strval(get_the_ID()),
                    'slug' => basename(get_permalink()),
                    'title' => get_the_title(),
                    'excerpt' => get_the_excerpt(),
                    'content' => array(wp_strip_all_tags(get_the_content())),
                    'date' => get_the_date('M j, Y'),
                    'author' => get_the_title(),
                    'readTime' => '5 min read',
                    'image' => get_the_post_thumbnail_url(get_the_ID(), 'full') ?: '',
                    'category' => 'Impact Stories',
                    'quote' => $quote,
                    'authorRole' => $author_role,
                    'avatarInitials' => $avatar_initials
                );
                echo json_encode($story_data) . ',';
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
    ];
    
    window.wpTeamMembers = [
        <?php
        $args = array('post_type' => 'team_member', 'posts_per_page' => -1);
        $query = new WP_Query($args);
        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
                $role = get_post_meta(get_the_ID(), 'member_role', true) ?: 'Team Member';
                $bio = get_post_meta(get_the_ID(), 'member_bio', true) ?: '';
                $initials = get_post_meta(get_the_ID(), 'member_initials', true) ?: substr(get_the_title(), 0, 2);
                
                $member_data = array(
                    'name' => get_the_title(),
                    'role' => $role,
                    'bio' => $bio,
                    'initials' => $initials,
                    'image' => get_the_post_thumbnail_url(get_the_ID(), 'full') ?: ''
                );
                echo json_encode($member_data) . ',';
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
    ];

    window.wpEvents = [
        <?php
        $args = array('post_type' => 'event', 'posts_per_page' => -1, 'post_status' => 'publish');
        $query = new WP_Query($args);
        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
                $date = get_post_meta(get_the_ID(), 'event_date', true) ?: '';
                $time = get_post_meta(get_the_ID(), 'event_time', true) ?: '';
                $location = get_post_meta(get_the_ID(), 'event_location', true) ?: '';
                $link = get_post_meta(get_the_ID(), 'event_link', true) ?: '';
                
                $event_data = array(
                    'id' => strval(get_the_ID()),
                    'title' => get_the_title(),
                    'description' => wp_strip_all_tags(get_the_content()),
                    'date' => $date,
                    'time' => $time,
                    'location' => $location,
                    'link' => $link ?: get_permalink(),
                    'image' => get_the_post_thumbnail_url(get_the_ID(), 'full') ?: ''
                );
                echo json_encode($event_data) . ',';
            endwhile;
            wp_reset_postdata();
        endif;
        ?>
    ];
    </script>

    <div id="root"><link rel="preload" as="image" href="<?php echo get_template_directory_uri(); ?>/assets/logo-white.png"/><link rel="preload" as="image" href="<?php echo get_template_directory_uri(); ?>/assets/empowerment-women.png"/><div class="min-h-screen bg-bg-coastal text-[#1A2D37] font-sans antialiased selection:bg-primary-container selection:text-primary"><nav class="fixed top-0 left-0 w-full z-50 transition-[background-color,border-color,box-shadow] duration-300 bg-transparent border-b border-transparent shadow-none"><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><div class="flex justify-between h-20 items-center"><a href="#" class="flex items-center group py-1"><img src="<?php echo get_template_directory_uri(); ?>/assets/logo-white.png" alt="Two-Thirds Community Foundation" class="h-11 sm:h-12 w-auto object-contain transition-all duration-300 group-hover:scale-105"/></a><div class="hidden md:flex items-center gap-8 font-sans font-medium text-sm transition-colors duration-300 text-white"><a href="#" class="hover:text-secondary transition-colors font-bold ">Home</a><a href="#about-us" class="hover:text-secondary transition-colors font-bold ">About Us</a><div class="relative"><button class="hover:text-secondary transition-colors font-bold flex items-center gap-1.5 pb-2 pt-2 cursor-pointer text-[#FFB076] border-b-2 border-[#FFB076]">Programmes<svg class="w-3.5 h-3.5 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="transform:rotate(0deg)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 9l-7 7-7-7"></path></svg></button></div><a href="#team" class="hover:text-secondary transition-colors font-bold ">Our Team</a><a href="#get-involved" class="bg-primary hover:bg-primary-light text-white font-display font-semibold text-xs tracking-wider px-5 py-2.5 rounded-xl transition-all shadow-md active:scale-95 uppercase">Get Involved</a></div><div class="flex md:hidden"><button class="transition-colors duration-300 text-white hover:text-secondary focus:outline-none" aria-label="Toggle Navigation Menu"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-menu w-6 h-6" aria-hidden="true"><path d="M4 5h16"></path><path d="M4 12h16"></path><path d="M4 19h16"></path></svg></button></div></div></div></nav><div class="bg-stone-50 min-h-screen text-stone-800"><section class="relative h-[50vh] sm:h-[60vh] flex items-center justify-center overflow-hidden bg-[#7F1D1D]"><img src="<?php echo get_template_directory_uri(); ?>/assets/empowerment-women.png" alt="Women Empowerment Kerala Coast" class="absolute inset-0 w-full h-full object-cover opacity-20 filter brightness-90"/><div class="absolute inset-0 bg-gradient-to-t from-stone-900 via-[#7F1D1D]/70 to-transparent"></div><div class="relative z-10 max-w-5xl mx-auto px-4 text-center space-y-4"><span class="inline-flex items-center gap-1.5 text-secondary font-mono text-xs font-bold uppercase tracking-widest bg-white/10 px-3.5 py-1.5 rounded-full backdrop-blur-md"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-anchor w-3.5 h-3.5 text-secondary" aria-hidden="true"><path d="M12 6v16"></path><path d="m19 13 2-1a9 9 0 0 1-18 0l2 1"></path><path d="M9 11h6"></path><circle cx="12" cy="4" r="2"></circle></svg>Coastal Women&#x27;s Initiative</span><h1 class="font-display font-bold text-4xl sm:text-6xl text-white tracking-tight leading-tight">WOMEN&#x27;S EMPOWERMENT</h1><div class="h-1 bg-secondary mx-auto rounded-full w-20"></div><p class="text-stone-200 text-xs sm:text-sm max-w-xl mx-auto leading-relaxed font-sans font-medium">Building economic agency and social resilience for women across coastal Kerala.</p></div></section><section class="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24"><div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center"><div class="lg:col-span-7 space-y-6"><span class="inline-block text-secondary font-mono text-xs font-bold uppercase tracking-wider">Womanhood &amp; Solidarity</span><h2 class="font-display font-bold text-3xl sm:text-4xl text-primary leading-tight">Coastal Solidarity: Nurturing Strength on the Shoreline</h2><p class="text-stone-600 text-sm sm:text-base leading-relaxed font-sans">The life of women in coastal Perumathura is shaped by a complex interplay of environmental vulnerability, economic precarity, and deep-rooted social structures. The collapse of fishing due to climate change has eroded traditional household income, forcing women into insecure, low-wage work while managing heavy domestic responsibilities.</p><p class="text-stone-600 text-sm sm:text-base leading-relaxed font-sans">Our <strong>Women&#x27;s Solidarity and Empowerment Initiative</strong> was launched in response to provide economic and social security to women. Since its inception in 2010, this movement has stood as a pillar of strength and support within the community, offering a cooperative voice for women to organize, learn, and grow.</p></div><div class="lg:col-span-5 bg-white p-8 rounded-3xl border border-stone-200/80 shadow-sm grid grid-cols-2 gap-6 text-center"><div class="space-y-2 p-6 rounded-2xl bg-stone-50 border border-stone-100"><h3 class="font-display font-extrabold text-4xl text-primary">250+</h3><p class="text-[10px] font-mono uppercase tracking-widest text-stone-500 font-bold">Beneficiaries</p></div><div class="space-y-2 p-6 rounded-2xl bg-stone-50 border border-stone-100"><h3 class="font-display font-extrabold text-4xl text-secondary">35+</h3><p class="text-[10px] font-mono uppercase tracking-widest text-stone-500 font-bold">Active Members</p></div><div class="col-span-2 space-y-2 p-6 rounded-2xl bg-stone-50 border border-stone-100"><h3 class="font-display font-extrabold text-2xl text-[#0A5F8F]">15 Years</h3><p class="text-[10px] font-mono uppercase tracking-widest text-stone-500 font-bold">of Coastal Solidarity</p></div></div></div><div class="space-y-12"><div class="text-center space-y-3"><h2 class="font-display font-bold text-2xl sm:text-3xl text-primary">Core Action Areas</h2><div class="w-12 h-1 bg-secondary mx-auto rounded-full"></div></div><div class="grid grid-cols-1 md:grid-cols-2 gap-8 text-left"><div class="bg-white p-8 rounded-3xl border border-stone-200/60 shadow-sm flex gap-6 items-start"><div class="p-3 rounded-2xl shrink-0 text-amber-600 bg-amber-50"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-anchor w-6 h-6" aria-hidden="true"><path d="M12 6v16"></path><path d="m19 13 2-1a9 9 0 0 1-18 0l2 1"></path><path d="M9 11h6"></path><circle cx="12" cy="4" r="2"></circle></svg></div><div class="space-y-2"><h3 class="font-display font-bold text-lg text-primary">Entrepreneurship &amp; Craft Co-ops</h3><p class="text-stone-600 text-xs leading-relaxed font-sans">Trained 100+ women in producing eco-friendly bags, skillfully linking traditional craftsmanship with environmental sustainability and income generation.</p></div></div><div class="bg-white p-8 rounded-3xl border border-stone-200/60 shadow-sm flex gap-6 items-start"><div class="p-3 rounded-2xl shrink-0 text-red-600 bg-red-50"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-life-buoy w-6 h-6" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m4.93 4.93 4.24 4.24"></path><path d="m14.83 9.17 4.24-4.24"></path><path d="m14.83 14.83 4.24 4.24"></path><path d="m9.17 14.83-4.24 4.24"></path><circle cx="12" cy="12" r="4"></circle></svg></div><div class="space-y-2"><h3 class="font-display font-bold text-lg text-primary">Community Health &amp; Welfare</h3><p class="text-stone-600 text-xs leading-relaxed font-sans">Organizing cancer detection camps and health awareness classes in collaboration with the State Chief Minister&#x27;s Cancer Detection Programs and Snehita Women&#x27;s Health Foundation.</p></div></div><div class="bg-white p-8 rounded-3xl border border-stone-200/60 shadow-sm flex gap-6 items-start"><div class="p-3 rounded-2xl shrink-0 text-teal-600 bg-teal-50"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shield-check w-6 h-6" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg></div><div class="space-y-2"><h3 class="font-display font-bold text-lg text-primary">Digital &amp; Financial Literacy</h3><p class="text-stone-600 text-xs leading-relaxed font-sans">Mobilizing micro-savings Self-Help Groups (SHGs) and training women in digital banking (UPI) and micro-enterprise financial management.</p></div></div><div class="bg-white p-8 rounded-3xl border border-stone-200/60 shadow-sm flex gap-6 items-start"><div class="p-3 rounded-2xl shrink-0 text-indigo-600 bg-indigo-50"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-book-open w-6 h-6" aria-hidden="true"><path d="M12 7v14"></path><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"></path></svg></div><div class="space-y-2"><h3 class="font-display font-bold text-lg text-primary">Scholastic &amp; Merit Awards</h3><p class="text-stone-600 text-xs leading-relaxed font-sans">Supporting deserving and talented female students to pursue their educational dreams, ensuring long-term progress for families and the shoreline.</p></div></div></div></div><div class="bg-[#FFF9E6]/50 border border-amber-200/40 p-8 sm:p-12 rounded-3xl space-y-8 text-left"><div class="space-y-3"><span class="text-amber-700 font-mono text-xs font-bold uppercase tracking-wider">Proposed Programmes (2026-2027)</span><h2 class="font-display font-bold text-2xl sm:text-3xl text-primary">Holistic Development Roadmap</h2><p class="text-stone-600 text-sm font-sans max-w-3xl">Evidence from our 15 years of work highlights two pressing challenges that we will begin addressing with a comprehensive needs-assessment study in 2026-2027:</p></div><div class="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4"><div class="bg-white p-6 sm:p-8 rounded-2xl border border-amber-100 shadow-sm space-y-4"><div class="p-2.5 bg-amber-50 rounded-xl text-amber-700 w-fit"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-compass w-5 h-5" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z"></path></svg></div><h3 class="font-display font-bold text-lg text-primary">Women Led Households</h3><p class="text-stone-600 text-xs leading-relaxed font-sans">High divorce rates result in many female-headed households with limited livelihood opportunities (with only a quarter of employed women earning year-round incomes). Guided by these insights, our focus will be to co-create a strategic plan for holistic development—one that addresses economic vulnerability while strengthening the social and emotional resilience of women and their families.</p></div><div class="bg-white p-6 sm:p-8 rounded-2xl border border-amber-100 shadow-sm space-y-4"><div class="p-2.5 bg-amber-50 rounded-xl text-amber-700 w-fit"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-waves-horizontal w-5 h-5" aria-hidden="true"><path d="M2 12q2.5 2 5 0t5 0 5 0 5 0"></path><path d="M2 19q2.5 2 5 0t5 0 5 0 5 0"></path><path d="M2 5q2.5 2 5 0t5 0 5 0 5 0"></path></svg></div><h3 class="font-display font-bold text-lg text-primary">Gender Volunteers</h3><p class="text-stone-600 text-xs leading-relaxed font-sans">We are building a network of local women trained to serve as the first points of contact, listeners, and guides. As peers, they understand cultural nuances and daily struggles, making their support authentic and effective. These volunteers provide peer-to-peer guidance, identify community needs, connect women to resources, and act as champions of change.</p></div></div></div></section></div><footer class="relative z-10 bg-stone-900 text-stone-300 pt-16 pb-8 border-t-8 border-primary"><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid gap-12 md:grid-cols-12 pb-12 border-b border-white/5 text-left"><div class="md:col-span-5 space-y-4"><div class="flex items-center"><img src="<?php echo get_template_directory_uri(); ?>/assets/logo-white.png" alt="Two-Thirds Community Foundation" class="h-12 sm:h-14 w-auto object-contain"/></div><p class="text-xs text-stone-400 leading-relaxed max-w-sm">Registered Section 8 nonprofit dedicated to empowering coastal fishing hamlets and traditional communities across Kerala, India through education, sustainable livelihoods, and climate resilience.</p><div class="space-y-1 font-mono text-[10px] text-stone-500"><p>CIN Identification Code: U88900KL2026NPL100608</p><p>Registered under Section 8(1) of the Companies Act, 2013</p></div></div><div class="md:col-span-3 space-y-3"><h4 class="font-display font-semibold text-stone-200 text-sm">Focus Anchors</h4><div class="grid gap-2 text-xs"><a href="#about-us" class="text-stone-400 hover:text-secondary transition-colors">About Us</a><a href="#get-involved" class="text-stone-400 hover:text-secondary transition-colors">Get Involved</a><a href="#programs" class="text-stone-400 hover:text-secondary transition-colors">Strategic Focus Areas</a><a href="#team" class="text-stone-400 hover:text-secondary transition-colors">Meet the Team</a></div></div><div class="md:col-span-4 space-y-4"><h4 class="font-display font-semibold text-stone-200 text-sm">Regulatory Compliance</h4><div class="text-xs text-stone-400 space-y-2"><p class="flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shield-check w-4 h-4 text-secondary shrink-0" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg><span>Fully compliant with Section 135 &amp; 80G tax exemptions.</span></p><p class="text-[10px] font-mono text-stone-500 leading-normal">Donations are audit-logged and eligible for Corporate Social Responsibility credit allocations under Indian tax guidelines.</p></div><div class="flex items-center gap-4 pt-2"><a href="https://instagram.com" target="_blank" rel="noopener noreferrer" class="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 flex items-center justify-center transition-colors text-white" aria-label="Instagram"><svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.051.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"></path></svg></a><a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" class="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 flex items-center justify-center transition-colors text-white" aria-label="LinkedIn"><svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"></path></svg></a><a href="https://twitter.com" target="_blank" rel="noopener noreferrer" class="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 flex items-center justify-center transition-colors text-white" aria-label="Twitter"><svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"></path></svg></a></div></div></div><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] text-stone-500 font-mono"><p>© <!-- -->2026<!-- --> Two-Thirds Community Foundation. All rights reserved.</p><div class="flex items-center gap-1.5"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shield-check w-4 h-4 text-secondary" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg><span>Under section 80G credits, Income Tax Department, India</span></div></div></footer></div></div>

    <?php wp_footer(); ?>
</body>
</html>
